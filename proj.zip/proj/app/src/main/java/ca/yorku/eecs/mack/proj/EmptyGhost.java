package ca.yorku.eecs.mack.proj;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Picture;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;

public class EmptyGhost {


    public EmptyGhost(){

    }

    public void init(){


    }


    public void update(){

    }

    public void draw(){

    }


}
